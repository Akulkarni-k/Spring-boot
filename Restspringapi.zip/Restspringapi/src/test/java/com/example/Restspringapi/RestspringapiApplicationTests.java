package com.example.Restspringapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestspringapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
